<?php
header("Location: ../");
?>